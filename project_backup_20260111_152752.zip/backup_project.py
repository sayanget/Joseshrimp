
import os
import zipfile
import datetime

def backup_project():
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_filename = f'project_backup_{timestamp}.zip'
    
    # Files/Dirs to exclude
    EXCLUDE = {
        'venv', '__pycache__', '.git', '.idea', '.vscode', 
        'instance', 'project_backup_', '.pytest_cache', 'node_modules'
    }
    
    print(f"Creating backup: {backup_filename}")
    
    try:
        with zipfile.ZipFile(backup_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk('.'):
                # Modify dirs in-place to skip excluded directories
                dirs[:] = [d for d in dirs if d not in EXCLUDE]
                
                for file in files:
                    # Skip backup files themselves and python cache files
                    if file.startswith('project_backup_') or file.endswith('.pyc'):
                        continue
                        
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, '.')
                    
                    # Check if file path contains excluded dir (double check)
                    if any(excluded in file_path.split(os.sep) for excluded in EXCLUDE):
                        continue
                        
                    print(f"Adding: {arcname}")
                    zipf.write(file_path, arcname)
                    
        print(f"\nBackup created successfully: {os.path.abspath(backup_filename)}")
        
    except Exception as e:
        print(f"Backup failed: {e}")

if __name__ == '__main__':
    backup_project()
